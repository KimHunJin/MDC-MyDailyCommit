package algorithm.synap;

public class TestCase {

    private int size;

    public TestCase(int size) {
        this.size = size;
    }

    public int[][] getTile() {
        return makeTile();
    }

    private int[][] makeTile() {
        int tile[][] = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                tile[i][j] = (int) (Math.random() * 4) + 1;
            }
        }
        return tile;
    }
}
