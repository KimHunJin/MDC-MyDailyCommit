package algorithm.synap;

public class Main {

    private int[][] tile;

    public static void main(String[] args) {
        new Main().solve();
    }

    private void solve() {
//        tile = new TestCase(5).getTile();
        tile = new TextRead().getTile();
        boom();
        print();
    }


    private void boom() {
        while (isCheckBoom()) {
            remove();
            down();
        }
    }

    private void remove() {
        int row = tile.length;
        int col = tile[0].length;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (tile[i][j] > 100) {
                    tile[i][j] = 0;
                }
            }
        }
    }

    private void down() {
        int row = tile.length;
        int col = tile[0].length;
        for (int i = row - 1; i >= 0; i--) {
            for (int j = 0; j < col; j++) {
                if (tile[i][j] == 0) {
                    for (int r = i; r > 0; r--) {
                        tile[r][j] = tile[r - 1][j];
                    }
                    tile[0][j] = 100;
                    j--;
                }
            }
        }
    }

    private boolean isCheckBoom() {

        int row = tile.length;
        int col = tile[0].length;

        boolean isCheck = false;

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                int temp = tile[i][j] % 100;
                if (temp == 0) {
                    continue;
                }
                int width = checkWidth(temp, i + 1, j, 1);
                int height = checkHeight(temp, i, j + 1, 1);

                if (width >= 3) {
                    isCheck = true;
                    for (int k = i; k < i + width; k++) {
                        tile[k][j] += 100;
                    }
                }
                if (height >= 3) {
                    isCheck = true;
                    for (int k = j; k < j + height; k++) {
                        tile[i][k] += 100;
                    }
                }
            }
        }

        return isCheck;
    }

    private int checkWidth(int value, int row, int col, int width) {
        if (row < tile.length && (tile[row][col]) % 100 == value) {
            return checkWidth(value, row + 1, col, width + 1);
        } else {
            return width;
        }
    }

    private int checkHeight(int value, int row, int col, int height) {
        if (col < tile[0].length && (tile[row][col]) % 100 == value) {
            return checkHeight(value, row, col + 1, height + 1);
        } else {
            return height;
        }
    }

    private void print() {
        for(int row[] : tile) {
            for(int col: row) {
                System.out.print(col%100 + " ");
            }
            System.out.println();
        }
    }
}
