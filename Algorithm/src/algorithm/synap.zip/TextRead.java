package algorithm.synap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextRead {

    private int size = 5;

    public TextRead(int size) {
        this.size = size;
    }

    public TextRead() {
        this.size = 5;
    }

    public int[][] getTile() {
        return makeTile();
    }


    private int[][] makeTile() {
        String[] line = null;
        int[][] tile = new int[size][];
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            for (int i = 0; i < size; i++) {
                line = br.readLine().split(" ");
                tile[i] = convertLine(line);
            }
        } catch (IOException ie) {
            ie.printStackTrace();
        }
        return tile;
    }

    private int[] convertLine(String[] line) {
        int[] row = new int[size];
        for (int i = 0; i < size; i++) {
            row[i] = convertInteger(line[i]);
        }
        return row;
    }

    private int convertInteger(String word) {
        return Integer.parseInt(word);
    }
}
